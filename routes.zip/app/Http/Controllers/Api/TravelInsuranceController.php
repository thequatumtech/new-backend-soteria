<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\InsurancePlanModels\TravelPlan;
use App\Models\{ClientTravelInsurance, FamilyTravelInsuranceMember, PurchasePolicy};
use PDF;
use App\Models\Client;
use App\Models\InsuranceCompany;
use Carbon\Carbon;
use App\Models\Currency;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\TravelPlanPricingSchedule;
use App\Helpers\InsurancePlanHelper;

use App\Models\RenewalPolicy;


class TravelInsuranceController extends Controller
{
    private function normalizeRestricted($value)
    {
        if (!$value) return [];

        if (is_string($value) && str_starts_with($value, '[')) {
            return array_map('trim', json_decode($value, true));
        }

        if (is_string($value)) {
            return array_map('trim', explode(',', $value));
        }

        if (is_numeric($value)) {
            return [(int)$value];
        }
        return [];
    }

    private function restrictionError($type)
    {
        $message = __('messages.api.travel_restriction_message', [
            'type' => __('messages.api.travel_restriction_' . $type)
        ]);

        if ($type === 'country') {
            $message .= __('messages.api.country_contact');
        }

        return response()->json([
            'status' => false,
            'status_code' => 422,
            'message' => $message,
            'data' => []
        ], 422);
    }

    private function normalizeDate($date)
    {
        if (!$date) return null;

        if (preg_match('/^\d{2}-\d{2}-\d{4}$/', $date)) {
            return Carbon::createFromFormat('m-d-Y', $date)->format('Y-m-d');
        }

        return $date;
    }

    public function storeTravelInsurance(Request $request)
    {
        try {
            $data = $request->validate([
                'self_family_status' => 'nullable',
                'first_name' => 'nullable',
                'last_name' => 'nullable',
                'third_name' => 'nullable',
                'family_name' => 'nullable',
                'nationality' => 'nullable',
                'nationality_no' => 'nullable',
                'id_residence_no' => 'nullable',
                'birth_date' => 'nullable',
                'gender' => 'nullable',
                'marital_status' => 'nullable',
                'place_residence' => 'nullable',
                'passport_document' => 'nullable',
                'departure_from_country_id' => 'nullable',
                'destination_country_id' => 'nullable',
                'additional_destination_country_id' => 'nullable',
                'geographical_countries' => 'nullable',
                'geographical_area_id' => 'nullable',
                'effective_date' => 'nullable',
                'travel_days' => 'nullable',
                'expiry_date' => 'nullable',
                'insurance_limit' => 'nullable',
                'plan_id' => 'required',
                'payment_status' => 'nullable',
                'multiple_destination' => 'nullable',
                'dangerous_activities' => 'nullable',
                'old_policy_id_for_renew' => 'nullable|integer',
                'renew' => 'nullable|boolean',
            ]);

            if ($request->has('dangerous_activities')) {
                $data['dangerous_activities'] = is_array($request->dangerous_activities)
                    ? implode(',', $request->dangerous_activities)
                    : $request->dangerous_activities;
            }

            if ($request->has('multiple_destination')) {
                $data['multiple_destination'] = is_array($request->multiple_destination)
                    ? implode(',', $request->multiple_destination)
                    : $request->multiple_destination;
            }

            if ($request->has('geographical_countries')) {
                $data['geographical_countries'] = is_array($request->geographical_countries)
                    ? json_encode($request->geographical_countries)
                    : $request->geographical_countries;
            }

            if (!empty($request->effective_date)) {
                $data['effective_date'] = date('Y-m-d', strtotime($request->effective_date));
            }

            if (!empty($request->expiry_date)) {
                $data['expiry_date'] = date('Y-m-d', strtotime($request->expiry_date));
            }

            $data['inception_date'] = $data['effective_date'] ?? null;

            // $plan_data = TravelPlan::find($data['plan_id']);
            $plan_data = TravelPlan::with('insurance_company.currency')->find($data['plan_id']);

            $data['insurance_company_id'] = $plan_data->insurance_company_id ?? 0;

            $client = Client::find($request->user_id);
            if (!$client) {
                return response()->json([
                    'status' => false,
                    'status_code' => 422,
                    'message' => __('messages.api.client_not_found'),
                    'data' => []
                ], 422);
            }

            $clientCountry  = $client->country_id;
            $clientCity     = $client->city_id;
            $clientDistrict = $client->district_id;
            $userDangerousActivities = [];
            $clientAge = Carbon::parse($client->birth_date)->age;

            $restrictedCountries = $this->normalizeRestricted($plan_data->restricted_country_ids);
            $restrictedCities    = $this->normalizeRestricted($plan_data->restricted_city_ids);
            $restrictedDistricts = $this->normalizeRestricted($plan_data->restricted_district_ids);
            $restrictedAges      = $this->normalizeRestricted($plan_data->restricted_age_ids);
            $restrictedDangerousActivities = $this->normalizeRestricted($plan_data->restricted_dangerous_activities_ids ?? null);
            $restrictedDestinationCountries = $this->normalizeRestricted($plan_data->restricted_destination_country_ids ?? null);
            if ($clientCountry && in_array($clientCountry, $restrictedCountries)) {
                return $this->restrictionError('country');
            }

            if ($clientCity && in_array($clientCity, $restrictedCities)) {
                return $this->restrictionError('city');
            }

            if ($clientDistrict && in_array($clientDistrict, $restrictedDistricts)) {
                return $this->restrictionError('district');
            }

            if (!empty($data['dangerous_activities'])) {
                $userDangerousActivities = is_array($data['dangerous_activities'])
                    ? $data['dangerous_activities']
                    : explode(',', $data['dangerous_activities']);
            }
            foreach ($userDangerousActivities as $activityId) {
                if (in_array(trim($activityId), $restrictedDangerousActivities)) {
                    return $this->restrictionError('dangerous_activity');
                }
            }
            if (!empty($restrictedDestinationCountries) && !empty($data['destination_country_id'])) {
                if (in_array((int)$data['destination_country_id'], array_map('intval', $restrictedDestinationCountries))) {
                    return $this->restrictionError('destination_country');
                }
            }
            foreach ($restrictedAges as $range) {
                $range = str_replace(' ', '', $range);
                if (str_contains($range, '-')) {
                    [$min, $max] = explode('-', $range);
                    if ($clientAge >= (int)$min && $clientAge <= (int)$max) {
                        return $this->restrictionError('age');
                    }
                } else {
                    if ((int)$range === $clientAge) {
                        return $this->restrictionError('age');
                    }
                }
            }

            // -------------------------
            // Calculate travel days and net premium
            $effectiveDate = Carbon::parse($data['effective_date']);
            $expiryDate    = Carbon::parse($data['expiry_date']);
            $travelDays    = $effectiveDate->diffInDays($expiryDate);

            $pricing = \App\Models\TravelPlanPricingSchedule::where('travel_plan_id', $data['plan_id'])
                ->where('min_days', '<=', $travelDays)
                ->where('max_days', '>=', $travelDays)
                ->first();


            if (!$pricing) {
                return response()->json([
                    'status' => false,
                    'status_code' => 422,
                    'message' => __('messages.api.travel_no_pricing_available'),
                    'data' => []
                ], 422);
            }

            $netPremium = (float)$pricing->price;

            $surchargeBand = \App\Models\TravelPlanSurchargeBand::where('travel_plan_id', $data['plan_id'])
                ->where('min_age', '<=', $clientAge)
                ->where('max_age', '>=', $clientAge)
                ->first();

            if ($surchargeBand) {
                $netPremium += ($netPremium * $surchargeBand->surcharge) / 100;
            }

            $netPremium = round($netPremium, 2);
            // -------------------------

            // ---------- JOD Conversion Calculation ----------
            $feesPercentage      = (float)$plan_data->fees;
            $stampsPercentage    = (float)$plan_data->stamps;
            $salesTaxPercentage  = (float)$plan_data->sales_tax;

            $cbjTaxPercentage = (float)($plan_data->cbj ?? 0);
            $cbjSalesTaxPercentage = (float)($plan_data->sales_tax_cbj ?? 0);

            $feesAmount      = ($netPremium * $feesPercentage) / 100;
            $stampsAmount    = ($netPremium * $stampsPercentage) / 100;
            $cbjContribution = ($netPremium * $cbjTaxPercentage) / 100;
            $salesTaxAmount  = (($netPremium + $feesAmount) * $salesTaxPercentage) / 100;
            $cbjSalesTaxAmount = ($cbjContribution * $cbjSalesTaxPercentage) / 100;

            $grossPremium = $netPremium + $feesAmount + $stampsAmount + $salesTaxAmount + $cbjContribution + $cbjSalesTaxAmount;
            // ------------------------------------------------

            
            $oldPolicyForRenewal = null;

            if ($request->boolean('renew')) {

                $oldPolicyForRenewal = PurchasePolicy::find(
                    $request->old_policy_id_for_renew
                );

                if (!$oldPolicyForRenewal) {
                    return response()->json([
                        'status' => false,
                        'status_code' => 422,
                        'message' => __('messages.api.policy_not_found'),
                        'data' => [],
                    ], 422);
                }
            }

            $existingtravel = PurchasePolicy::find($request->purchase_id ?? 0);

            if ($existingtravel) {
                $travels = ClientTravelInsurance::find($existingtravel->policy_id);
                if ($travels) {
                    $travels->update($data);
                }

                $data['purchase_id'] = $existingtravel->id;
                $data['inception_date'] = $data['effective_date'];

                $travel = PurchasePolicy::updatePurchasePolicy($data);
                $data['policy_id'] = $travel->policy_id;
            } else {
                $data['client_id'] = $request->user_id;
                $data['police_no'] = rand(10000000, 99999999);

                $travel = ClientTravelInsurance::create($data);

                $data['policy_type'] = 10;
                $data['policy_id'] = $travel->id;
                $data['inception_date'] = $data['effective_date'];

                $travel = PurchasePolicy::savePurchasePolicy($data);


                if ($request->boolean('renew')) {

                    RenewalPolicy::create([
                        'old_policy_id' => $oldPolicyForRenewal->id,
                        'new_policy_id' => $travel->id,
                    ]);
                }

            }

            $data = ClientTravelInsurance::getTravelsInsuranceDetails($data['policy_id']);

            $directory = public_path('insurance_pdfs/travel_policy');
            if (!file_exists($directory)) {
                mkdir($directory, 0755, true);
            }

            $filename = uniqid() . '_policy_' . $travel->id . '.pdf';
            $path = $directory . '/' . $filename;

            // Save purchase with JOD values
            $purchase['net_premium']       = $netPremium;
            $purchase['fees']              = $feesAmount;
            $purchase['stamps']            = $stampsAmount;
            $purchase['sales_tax']         = $salesTaxAmount;
            $purchase['cbj']               = $cbjContribution;
            $purchase['sales_tax_cbj']     = $cbjSalesTaxAmount;
            $purchase['gross_premium']     = $grossPremium;
            $purchase['commission_amount'] = ($plan_data->commission_percentage ?? 0) / 100 * $netPremium;

            $purchase['purchase_id']           = $travel->id;
            $purchase['plan_id']               = $data->plan_id;
            $purchase['plan_name']             = $plan_data->plan_name;
            $purchase['policy_plan_limit']     = $plan_data->limit;
            $purchase['insurance_company_id']  = $data->insurance_company_id;
            $purchase['inception_date']        = $data['effective_date'];
            $purchase['expiry_date']           = $data['expiry_date'];
            $purchase['commission_percentage'] = $plan_data->commission_percentage ?? 0;
            $purchase['policy_pdf_url']        = $path;

            PurchasePolicy::updatePurchasePolicy($purchase);

            $data->purchase_id = $travel->id;
            $data->purchase_policy_id = $travel->id;

            $plan_for_pdf = clone $plan_data;
            $plan_for_pdf->net_premium_amount = $netPremium;
            $plan_for_pdf->fees_amount = $feesAmount;
            $plan_for_pdf->stamps_amount = $stampsAmount;
            $plan_for_pdf->sales_tax_amount = $salesTaxAmount;
            $plan_for_pdf->cbj_amount = $cbjContribution;
            $plan_for_pdf->sales_tax_cbj_amount = $cbjSalesTaxAmount;
            $plan_for_pdf->gross_premium_amount = $grossPremium;
            if (!isset($plan_for_pdf->cbj)) $plan_for_pdf->cbj = $cbjTaxPercentage;
            if (!isset($plan_for_pdf->sales_tax_cbj)) $plan_for_pdf->sales_tax_cbj = $cbjSalesTaxPercentage;

            // $client = Client::with('country.currency')->find($request->user_id);
            // $abbr = optional(optional($client->country)->currency)->abbreviation ?? 'JOD';
            $client = Client::with('country.currency')->find($request->user_id);
            // Get insurance company currency first
            $insuranceCompany = $plan_data->insurance_company;
            if ($insuranceCompany && $insuranceCompany->currency) {
                $abbr = $insuranceCompany->currency->abbreviation;
            } else {
                // Fallback to client's country currency
                $abbr = optional(optional($client->country)->currency)->abbreviation ?? 'JOD';
            }


            $pdf = PDF::loadView('pdf/travel_policy', [
                'data' => $data,
                'abbr' => $abbr,
                'plan' => $plan_for_pdf
            ]);
            $pdf->save($path);

            $data['url'] = url('insurance_pdfs/travel_policy/' . $filename);



            // Format values in JOD instead of %
            $data->net_premium = number_format($purchase['net_premium'], 2) . ' ' . $abbr;
            $data->fees = number_format($purchase['fees'], 2) . ' ' . $abbr;
            $data->gross_premium = number_format($purchase['gross_premium'], 2) . ' ' . $abbr;
            $data->sales_tax = number_format($purchase['sales_tax'], 2) . ' ' . $abbr;
            $data->cbj = number_format($purchase['cbj'], 2) . ' ' . $abbr;
            $data->sales_tax_cbj = number_format($purchase['sales_tax_cbj'], 2) . ' ' . $abbr;
            $data->stamps = number_format($purchase['stamps'], 2) . ' ' . $abbr;
            $data->commission_amount = number_format($purchase['commission_amount'], 2) . ' ' . $abbr;

            if (!empty($request->members)) {
                foreach ($request->members as $single) {
                    $family_member = new FamilyTravelInsuranceMember();
                    $family_member->client_insurance_id = $travel->id;
                    $family_member->first_name = $single['first_name'];
                    $family_member->last_name = $single['last_name'];
                    $family_member->third_name = $single['third_name'];
                    $family_member->family_name = $single['family_name'];
                    $family_member->relation = $single['relation'];
                    $family_member->nationality = $single['nationality'];
                    $family_member->nationality_no = $single['nationality_no'];
                    $family_member->id_residence_no = $single['id_residence_no'];
                    $family_member->birth_date = $single['birth_date'];
                    $family_member->gender = $single['gender'];
                    $family_member->place_residence = $single['place_residence'];
                    $family_member->passport_document = $single['passport_document'];
                    $family_member->save();
                }
            }

            return response()->json([
                'status' => true,
                'status_code' => 200,
                'message' => __('messages.api.add_travel_insurance_plan_successfully'),
                'data' => $data
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'status_code' => 500,
                'message' => $e->getMessage(),
                'data' => []
            ]);
        }
    }

    // public function getTravelInsurancePlan(Request $request)
    // {
    //     try {
    //         $data = TravelPlan::with('policy_covers', 'insurance_company')
    //             ->whereHas('insurance_company', function ($q) {
    //                 $q->whereNull('deleted_at');
    //             });
    //             // ->where('plan_name', 'LIKE', '%' . $request->plan . '%');
    //             if ($request->has('plan') && !empty($request->plan)) {
    //             $data->where('plan_name', 'LIKE', '%' . $request->plan . '%');
    //         }

    //         if ($request->has('destination_country_id') && !empty($request->destination_country_id)) {
    //             $data->where(function ($query) use ($request) {
    //                 $query->whereJsonContains('countries', (string)$request->destination_country_id)
    //                 ->orWhereJsonContains('countries', (int)$request->destination_country_id)
    //                       ->orWhereHas('geographical_area', function ($q) use ($request) {
    //                           $q->whereJsonContains('countries', (string)$request->destination_country_id)

    //                       ->orWhereJsonContains('countries', (int)$request->destination_country_id);
    //             });
    //            });
    //         }

    //         if ($request->has('departure_from_country_id') && !empty($request->departure_from_country_id)) {
    //             $data->where(function ($query) use ($request) {
    //                 $query->whereNull('restricted_country_ids')
    //                       ->orWhere(function($q) use ($request) {
    //                           $q->whereJsonDoesntContain('restricted_country_ids', (string)$request->departure_from_country_id)
    //                             ->whereJsonDoesntContain('restricted_country_ids', (int)$request->departure_from_country_id);
    //                       });
    //             });
    //         }
    //         $data = $data->get();
    //         $data->transform(function ($item) {
    //             if (!empty($item->insurance_policy_pdf)) {
    //                 $item->insurance_policy_pdf = url('uploads/insurance_plans/' . $item->id . '/' . $item->insurance_policy_pdf);
    //             }
    //             if (!empty($item->insurance_company->privacy_policy)) {
    //                 $item->insurance_company->privacy_policy = url('insurance/' . $item->insurance_company->id . '/' . $item->insurance_company->privacy_policy);
    //             }
    //             return $item;
    //         });

    //         return response()->json([
    //             'status' => true,
    //             'status_code' => 200,
    //             'message' => 'Get Travel Insurance Plan successfully',
    //             'data' => $data
    //         ]);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => false,
    //             'status_code' => 500,
    //             'message' => $e->getMessage() . ' ' . $e->getFile() . ' ' . $e->getLine(),
    //             'data' => []
    //         ]);
    //     }
    // }

    public function getTravelInsurancePlan(Request $request)
    {
        try {

            $client = Client::find($request->user_id);

            if (!$client) {
                return response()->json([
                    'status' => false,
                    'status_code' => 404,
                    'message' => __('messages.api.client_not_found'),
                    'data' => [],
                    'total' => 0,
                ]);
            }


            $currency = Currency::where(
                'country_id',
                $client->country_id
            )->first();

            if (!$currency) {
                return response()->json([
                    'status' => true,
                    'status_code' => 200,
                    'message' => __('messages.api.no_currency_found'),
                    'data' => [],
                    'total' => 0,
                    'currency' => null,
                ]);
            }


            // $data = TravelPlan::with('policy_covers', 'insurance_company', 'geographical_area')
            //     ->whereHas('insurance_company', function ($q) {
            //         $q->whereNull('deleted_at');
            //     });

            /*
            |--------------------------------------------------------------------------
            | Plan Name
            |--------------------------------------------------------------------------
            */
            // if ($request->filled('plan')) {
            //     $data->where(
            //         'plan_name',
            //         'LIKE',
            //         '%' . $request->plan . '%'
            //     );
            // }
            $data = TravelPlan::with(
                'policy_covers',
                'insurance_company',
                'insurance_company.currency',
                'geographical_area'
            )
                ->whereHas('insurance_company', function ($q) {
                    $q->whereNull('deleted_at');
                });



            // Filter according to client's currency
            $data = InsurancePlanHelper::filterByClientCurrency(
                $data,
                $request->user_id
            );



            if ($request->filled('plan_id')) {
                $data->where('id', $request->plan_id);
            }
            /*
            |--------------------------------------------------------------------------
            | Destination Country
            |--------------------------------------------------------------------------
            */
            if ($request->filled('destination_country_id')) {

                $destinationCountryId = $request->destination_country_id;

                $data->where(function ($query) use ($destinationCountryId) {

                    $query->whereJsonContains(
                        'countries',
                        (string) $destinationCountryId
                    )
                        ->orWhereJsonContains(
                            'countries',
                            (int) $destinationCountryId
                        )
                        ->orWhereHas('geographical_area', function ($q) use ($destinationCountryId) {

                            $q->whereJsonContains(
                                'countries',
                                (string) $destinationCountryId
                            )
                                ->orWhereJsonContains(
                                    'countries',
                                    (int) $destinationCountryId
                                );
                        });
                });
            }

            /*
            |--------------------------------------------------------------------------
            | Departure Country Restriction
            |--------------------------------------------------------------------------
            */
            if ($request->filled('departure_from_country_id')) {

                $departureCountryId = $request->departure_from_country_id;

                $data->where(function ($query) use ($departureCountryId) {

                    $query->whereNull('restricted_country_ids')
                        ->orWhere(function ($q) use ($departureCountryId) {

                            $q->whereJsonDoesntContain(
                                'restricted_country_ids',
                                (string) $departureCountryId
                            )
                                ->whereJsonDoesntContain(
                                    'restricted_country_ids',
                                    (int) $departureCountryId
                                );
                        });
                });
            }

            $data = $data->get();

            /*
            |--------------------------------------------------------------------------
            | Travel Days
            |--------------------------------------------------------------------------
            */
            $travelDays = null;

            if ($request->filled('travel_days')) {
                $travelDays = (int) $request->travel_days;
            }

            /*
            |--------------------------------------------------------------------------
            | Transform Plans
            |--------------------------------------------------------------------------
            */
            $data->transform(function ($item) use ($travelDays) {

                /*
                |--------------------------------------------------------------------------
                | Default Premium Values
                |--------------------------------------------------------------------------
                */
                $item->travel_days = $travelDays;
                $item->pricing_schedule_id = null;

                $item->net_premium = null;
                $item->fees_amount = null;
                $item->stamps_amount = null;
                $item->sales_tax_amount = null;
                $item->cbj_amount = null;
                $item->sales_tax_cbj_amount = null;
                $item->gross_premium = null;

                /*
                |--------------------------------------------------------------------------
                | Calculate Premium According To Travel Days
                |--------------------------------------------------------------------------
                */
                if ($travelDays !== null) {

                    $pricing = TravelPlanPricingSchedule::where(
                        'travel_plan_id',
                        $item->id
                    )
                        ->where('min_days', '<=', $travelDays)
                        ->where('max_days', '>=', $travelDays)
                        ->first();

                    /*
                    |--------------------------------------------------------------------------
                    | Pricing Found
                    |--------------------------------------------------------------------------
                    */
                    if ($pricing) {

                        $netPremium = (float) $pricing->price;

                        /*
                        |--------------------------------------------------------------------------
                        | Calculate All Premium Values
                        |--------------------------------------------------------------------------
                        */
                        $premium = $this->calculateTravelPremium(
                            $netPremium,
                            $item
                        );

                        /*
                        |--------------------------------------------------------------------------
                        | Add Premium Data To Response
                        |--------------------------------------------------------------------------
                        */
                        $item->pricing_schedule_id = $pricing->id;

                        $item->net_premium = $premium['net_premium'];
                        $item->fees_amount = $premium['fees'];
                        $item->stamps_amount = $premium['stamps'];
                        $item->sales_tax_amount = $premium['sales_tax'];
                        $item->cbj_amount = $premium['cbj'];
                        $item->sales_tax_cbj_amount = $premium['sales_tax_cbj'];
                        $item->gross_premium = $premium['gross_premium'];

                        /*
                        |--------------------------------------------------------------------------
                        | Optional: Percentage Values
                        |--------------------------------------------------------------------------
                        */
                        $item->fees_percentage = $premium['fees_percentage'];
                        $item->stamps_percentage = $premium['stamps_percentage'];
                        $item->sales_tax_percentage = $premium['sales_tax_percentage'];
                        $item->cbj_percentage = $premium['cbj_percentage'];
                        $item->sales_tax_cbj_percentage =
                            $premium['sales_tax_cbj_percentage'];
                    } else {

                        /*
                        |--------------------------------------------------------------------------
                        | No Pricing Found
                        |--------------------------------------------------------------------------
                        */
                        $item->pricing_message =
                            __('messages.api.travel_no_pricing_available_days', [
                                'days' => $travelDays
                            ]);
                    }
                }

                /*
                |--------------------------------------------------------------------------
                | Insurance Policy PDF
                |--------------------------------------------------------------------------
                */
                if (!empty($item->insurance_policy_pdf)) {

                    $item->insurance_policy_pdf = url(
                        'uploads/insurance_plans/' .
                            $item->id .
                            '/' .
                            $item->insurance_policy_pdf
                    );
                }

                /*
                |--------------------------------------------------------------------------
                | Insurance Company Privacy Policy
                |--------------------------------------------------------------------------
                */
                if (!empty($item->insurance_company->privacy_policy)) {

                    $item->insurance_company->privacy_policy = url(
                        'insurance/' .
                            $item->insurance_company->id .
                            '/' .
                            $item->insurance_company->privacy_policy
                    );
                }

                return $item;
            });

            /*
            |--------------------------------------------------------------------------
            | Response
            |--------------------------------------------------------------------------
            */
            return response()->json([
                'status' => true,
                'status_code' => 200,
                'message' => __('messages.api.get_travel_insurance_plan_successfully'),
                'data' => $data
            ]);
        } catch (\Exception $e) {

            return response()->json([
                'status' => false,
                'status_code' => 500,
                'message' => $e->getMessage(),
                'data' => []
            ]);
        }
    }

    private function calculateTravelPremium(
        float $netPremium,
        $plan
    ): array {
        $feesPercentage = (float) ($plan->fees ?? 0);
        $stampsPercentage = (float) ($plan->stamps ?? 0);
        $taxPercentage = (float) ($plan->sales_tax ?? 0);
        $cbjTaxPercentage = (float) ($plan->cbj ?? 0);
        $cbjSalesTaxPercentage = (float) ($plan->sales_tax_cbj ?? 0);

        // Fees
        $feesAmount = ($netPremium * $feesPercentage) / 100;

        // Stamps
        $stampsAmount = ($netPremium * $stampsPercentage) / 100;

        // Sales Tax
        $taxAmount = (
            ($netPremium + $feesAmount)
            * $taxPercentage
        ) / 100;

        // CBJ Contribution
        $cbjContribution = (
            $netPremium
            * $cbjTaxPercentage
        ) / 100;

        // CBJ Sales Tax
        $cbjSalesTaxAmount = (
            $cbjContribution
            * $cbjSalesTaxPercentage
        ) / 100;

        // Gross Premium
        $grossPremium =
            $netPremium
            + $feesAmount
            + $stampsAmount
            + $taxAmount
            + $cbjContribution
            + $cbjSalesTaxAmount;

        return [
            'net_premium' => round($netPremium, 2),
            'fees' => round($feesAmount, 2),
            'stamps' => round($stampsAmount, 2),
            'sales_tax' => round($taxAmount, 2),
            'cbj' => round($cbjContribution, 2),
            'sales_tax_cbj' => round($cbjSalesTaxAmount, 2),
            'gross_premium' => round($grossPremium, 2),

            // Percentages
            'fees_percentage' => $feesPercentage,
            'stamps_percentage' => $stampsPercentage,
            'sales_tax_percentage' => $taxPercentage,
            'cbj_percentage' => $cbjTaxPercentage,
            'sales_tax_cbj_percentage' => $cbjSalesTaxPercentage,
        ];
    }
}
