<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VehicleType extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'vehicle_types';
    protected $dates = ['deleted_at'];
    protected $fillable = [
        'name',
        'vehicle_brand_id',
        'status'
    ];
}
